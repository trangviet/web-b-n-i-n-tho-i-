document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const forms = document.querySelectorAll('.auth-form');

    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
            }
        });
    });

    // Password visibility toggle
    const passwordToggles = document.querySelectorAll('.password-toggle');

    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function() {
            const passwordInput = this.previousElementSibling;
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.querySelector('i').classList.toggle('bi-eye');
            this.querySelector('i').classList.toggle('bi-eye-slash');
        });
    });

    // Form validation functions
    function validateForm(form) {
        let isValid = true;
        const inputs = form.querySelectorAll('input[required]');

        inputs.forEach(input => {
            if (!input.value.trim()) {
                showError(input, 'Vui lòng điền thông tin này');
                isValid = false;
            } else {
                clearError(input);
            }

            // Email validation
            if (input.type === 'email' && input.value.trim()) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(input.value.trim())) {
                    showError(input, 'Email không hợp lệ');
                    isValid = false;
                }
            }

            // Password validation
            if (input.type === 'password' && input.value.trim()) {
                if (input.value.length < 6) {
                    showError(input, 'Mật khẩu phải có ít nhất 6 ký tự');
                    isValid = false;
                }
            }
        });

        // Password confirmation validation
        const password = form.querySelector('input[type="password"]');
        const confirmPassword = form.querySelector('input[name="confirm_password"]');

        if (confirmPassword && password && confirmPassword.value !== password.value) {
            showError(confirmPassword, 'Mật khẩu không khớp');
            isValid = false;
        }

        return isValid;
    }

    function showError(input, message) {
        const formGroup = input.closest('.form-group');
        const errorDiv = formGroup.querySelector('.error-message') || document.createElement('div');

        errorDiv.className = 'error-message text-danger mt-1';
        errorDiv.textContent = message;

        if (!formGroup.querySelector('.error-message')) {
            formGroup.appendChild(errorDiv);
        }

        input.classList.add('is-invalid');
    }

    function clearError(input) {
        const formGroup = input.closest('.form-group');
        const errorDiv = formGroup.querySelector('.error-message');

        if (errorDiv) {
            errorDiv.remove();
        }

        input.classList.remove('is-invalid');
    }

    // Real-time validation
    const inputs = document.querySelectorAll('.auth-form input');

    inputs.forEach(input => {
        input.addEventListener('input', function() {
            if (this.value.trim()) {
                clearError(this);
            }
        });

        input.addEventListener('blur', function() {
            if (this.hasAttribute('required') && !this.value.trim()) {
                showError(this, 'Vui lòng điền thông tin này');
            }
        });
    });
});