document.addEventListener('DOMContentLoaded', function() {
    // Quantity controls
    const quantityInputs = document.querySelectorAll('.quantity-input');
    const quantityButtons = document.querySelectorAll('.quantity-btn');

    quantityInputs.forEach(input => {
        input.addEventListener('change', function() {
            updateCartItem(this);
        });
    });

    quantityButtons.forEach(button => {
        button.addEventListener('click', function() {
            const input = this.parentElement.querySelector('.quantity-input');
            const currentValue = parseInt(input.value);

            if (this.classList.contains('decrease')) {
                if (currentValue > 1) {
                    input.value = currentValue - 1;
                    updateCartItem(input);
                }
            } else {
                input.value = currentValue + 1;
                updateCartItem(input);
            }
        });
    });

    // Remove item buttons
    const removeButtons = document.querySelectorAll('.cart-item-remove');
    removeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const cartItem = this.closest('.cart-item');
            const productId = this.dataset.productId;

            removeCartItem(productId, cartItem);
        });
    });

    // Clear cart button
    const clearCartButton = document.querySelector('.clear-cart-btn');
    if (clearCartButton) {
        clearCartButton.addEventListener('click', function() {
            if (confirm('Bạn có chắc chắn muốn xóa tất cả sản phẩm trong giỏ hàng?')) {
                clearCart();
            }
        });
    }

    // Checkout button
    const checkoutButton = document.querySelector('.checkout-btn');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function() {
            window.location.href = 'checkout.php';
        });
    }

    // Functions
    function updateCartItem(input) {
        const cartItem = input.closest('.cart-item');
        const productId = cartItem.dataset.productId;
        const quantity = input.value;

        fetch('update_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `product_id=${productId}&quantity=${quantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateCartItemUI(cartItem, data);
                    updateCartSummary(data);
                } else {
                    showNotification(data.message || 'Có lỗi xảy ra', 'error');
                    // Reset input to previous value
                    input.value = data.previousQuantity || 1;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Có lỗi xảy ra', 'error');
                // Reset input to previous value
                input.value = 1;
            });
    }

    function removeCartItem(productId, cartItem) {
        fetch('remove_from_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `product_id=${productId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    cartItem.remove();
                    updateCartSummary(data);
                    updateCartCount(data.cartCount);

                    // Check if cart is empty
                    const remainingItems = document.querySelectorAll('.cart-item');
                    if (remainingItems.length === 0) {
                        showEmptyCart();
                    }

                    showNotification('Sản phẩm đã được xóa khỏi giỏ hàng', 'success');
                } else {
                    showNotification(data.message || 'Có lỗi xảy ra', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Có lỗi xảy ra', 'error');
            });
    }

    function clearCart() {
        fetch('clear_cart.php', {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const cartItems = document.querySelector('.cart-items');
                    cartItems.innerHTML = '';
                    updateCartSummary(data);
                    updateCartCount(0);
                    showEmptyCart();
                    showNotification('Giỏ hàng đã được xóa', 'success');
                } else {
                    showNotification(data.message || 'Có lỗi xảy ra', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Có lỗi xảy ra', 'error');
            });
    }

    function updateCartItemUI(cartItem, data) {
        const priceElement = cartItem.querySelector('.item-price');
        const subtotalElement = cartItem.querySelector('.item-subtotal');

        if (priceElement) {
            priceElement.textContent = formatPrice(data.itemPrice);
        }
        if (subtotalElement) {
            subtotalElement.textContent = formatPrice(data.itemSubtotal);
        }
    }

    function updateCartSummary(data) {
        const subtotalElement = document.querySelector('.summary-subtotal');
        const shippingElement = document.querySelector('.summary-shipping');
        const totalElement = document.querySelector('.summary-total');

        if (subtotalElement) {
            subtotalElement.textContent = formatPrice(data.subtotal);
        }
        if (shippingElement) {
            shippingElement.textContent = formatPrice(data.shipping);
        }
        if (totalElement) {
            totalElement.textContent = formatPrice(data.total);
        }
    }

    function updateCartCount(count) {
        const cartBadge = document.querySelector('.cart-badge');
        if (cartBadge) {
            cartBadge.textContent = count;
        }
    }

    function showEmptyCart() {
        const cartContainer = document.querySelector('.cart-container');
        const emptyCartHTML = `
            <div class="empty-cart">
                <i class="bi bi-cart-x"></i>
                <h3>Giỏ hàng trống</h3>
                <p>Bạn chưa có sản phẩm nào trong giỏ hàng</p>
                <a href="products.php" class="continue-shopping">Tiếp tục mua sắm</a>
            </div>
        `;

        cartContainer.innerHTML = emptyCartHTML;
    }

    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }

    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(price);
    }
});