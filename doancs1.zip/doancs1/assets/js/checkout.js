document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const checkoutForm = document.querySelector('.checkout-form');
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
            }
        });
    }

    // Payment method selection
    const paymentMethods = document.querySelectorAll('.payment-method');
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            const radio = this.querySelector('input[type="radio"]');
            radio.checked = true;

            // Update UI
            paymentMethods.forEach(m => m.classList.remove('selected'));
            this.classList.add('selected');
        });
    });

    // Address form toggle
    const addressToggle = document.querySelector('.address-toggle');
    if (addressToggle) {
        addressToggle.addEventListener('change', function() {
            const addressForm = document.querySelector('.address-form');
            if (addressForm) {
                addressForm.style.display = this.checked ? 'block' : 'none';
            }
        });
    }

    // Functions
    function validateForm(form) {
        let isValid = true;
        const requiredInputs = form.querySelectorAll('input[required], select[required]');

        requiredInputs.forEach(input => {
            if (!input.value.trim()) {
                showError(input, 'Vui lòng điền thông tin này');
                isValid = false;
            } else {
                clearError(input);
            }

            // Email validation
            if (input.type === 'email' && input.value.trim()) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(input.value.trim())) {
                    showError(input, 'Email không hợp lệ');
                    isValid = false;
                }
            }

            // Phone validation
            if (input.name === 'phone' && input.value.trim()) {
                const phoneRegex = /^[0-9]{10}$/;
                if (!phoneRegex.test(input.value.trim())) {
                    showError(input, 'Số điện thoại không hợp lệ');
                    isValid = false;
                }
            }
        });

        // Payment method validation
        const selectedPayment = form.querySelector('input[name="payment_method"]:checked');
        if (!selectedPayment) {
            const paymentError = document.querySelector('.payment-error') || document.createElement('div');
            paymentError.className = 'payment-error text-danger mt-2';
            paymentError.textContent = 'Vui lòng chọn phương thức thanh toán';

            const paymentMethods = document.querySelector('.payment-methods');
            if (paymentMethods && !paymentMethods.querySelector('.payment-error')) {
                paymentMethods.appendChild(paymentError);
            }

            isValid = false;
        } else {
            const paymentError = document.querySelector('.payment-error');
            if (paymentError) {
                paymentError.remove();
            }
        }

        return isValid;
    }

    function showError(input, message) {
        const formGroup = input.closest('.form-group');
        const errorDiv = formGroup.querySelector('.error-message') || document.createElement('div');

        errorDiv.className = 'error-message text-danger mt-1';
        errorDiv.textContent = message;

        if (!formGroup.querySelector('.error-message')) {
            formGroup.appendChild(errorDiv);
        }

        input.classList.add('is-invalid');
    }

    function clearError(input) {
        const formGroup = input.closest('.form-group');
        const errorDiv = formGroup.querySelector('.error-message');

        if (errorDiv) {
            errorDiv.remove();
        }

        input.classList.remove('is-invalid');
    }

    // Real-time validation
    const inputs = document.querySelectorAll('.checkout-form input, .checkout-form select');

    inputs.forEach(input => {
        input.addEventListener('input', function() {
            if (this.value.trim()) {
                clearError(this);
            }
        });

        input.addEventListener('blur', function() {
            if (this.hasAttribute('required') && !this.value.trim()) {
                showError(this, 'Vui lòng điền thông tin này');
            }
        });
    });

    // Order summary update
    function updateOrderSummary() {
        const formData = new FormData(checkoutForm);
        const params = new URLSearchParams();

        for (let [key, value] of formData.entries()) {
            if (value) {
                params.append(key, value);
            }
        }

        fetch(`update_order_summary.php?${params.toString()}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateSummaryUI(data);
                }
            })
            .catch(error => console.error('Error:', error));
    }

    function updateSummaryUI(data) {
        const subtotalElement = document.querySelector('.summary-subtotal');
        const shippingElement = document.querySelector('.summary-shipping');
        const totalElement = document.querySelector('.summary-total');

        if (subtotalElement) {
            subtotalElement.textContent = formatPrice(data.subtotal);
        }
        if (shippingElement) {
            shippingElement.textContent = formatPrice(data.shipping);
        }
        if (totalElement) {
            totalElement.textContent = formatPrice(data.total);
        }
    }

    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(price);
    }

    // Place order button
    const placeOrderBtn = document.querySelector('.place-order-btn');
    if (placeOrderBtn) {
        placeOrderBtn.addEventListener('click', function(e) {
            e.preventDefault();

            if (validateForm(checkoutForm)) {
                this.disabled = true;
                this.innerHTML = '<i class="bi bi-arrow-repeat spin"></i> Đang xử lý...';

                const formData = new FormData(checkoutForm);

                fetch('process_order.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            window.location.href = `order_success.php?order_id=${data.order_id}`;
                        } else {
                            showNotification(data.message || 'Có lỗi xảy ra', 'error');
                            this.disabled = false;
                            this.innerHTML = 'Đặt hàng';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showNotification('Có lỗi xảy ra', 'error');
                        this.disabled = false;
                        this.innerHTML = 'Đặt hàng';
                    });
            }
        });
    }

    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
});