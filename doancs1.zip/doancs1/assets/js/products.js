document.addEventListener('DOMContentLoaded', function() {
    // Product filtering
    const filterForm = document.querySelector('.filter-form');
    const productGrid = document.querySelector('.products-grid');

    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            filterProducts();
        });

        // Real-time filtering for price range
        const priceInputs = filterForm.querySelectorAll('input[type="number"]');
        priceInputs.forEach(input => {
            input.addEventListener('input', debounce(filterProducts, 500));
        });

        // Real-time filtering for category and brand
        const selectInputs = filterForm.querySelectorAll('select');
        selectInputs.forEach(select => {
            select.addEventListener('change', filterProducts);
        });
    }

    // Product search
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchTerm = this.querySelector('input').value.trim();
            if (searchTerm) {
                searchProducts(searchTerm);
            }
        });
    }

    // Product sorting
    const sortSelect = document.querySelector('.sort-select');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            sortProducts(this.value);
        });
    }

    // Quick view modal
    const quickViewButtons = document.querySelectorAll('.quick-view-btn');
    quickViewButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            showQuickView(productId);
        });
    });

    // Functions
    function filterProducts() {
        const formData = new FormData(filterForm);
        const params = new URLSearchParams();

        for (let [key, value] of formData.entries()) {
            if (value) {
                params.append(key, value);
            }
        }

        fetch(`products.php?${params.toString()}`)
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newProducts = doc.querySelector('.products-grid').innerHTML;
                productGrid.innerHTML = newProducts;
                initializeProductEvents();
            })
            .catch(error => console.error('Error:', error));
    }

    function searchProducts(term) {
        fetch(`products.php?search=${encodeURIComponent(term)}`)
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newProducts = doc.querySelector('.products-grid').innerHTML;
                productGrid.innerHTML = newProducts;
                initializeProductEvents();
            })
            .catch(error => console.error('Error:', error));
    }

    function sortProducts(sortBy) {
        const currentUrl = new URL(window.location.href);
        currentUrl.searchParams.set('sort', sortBy);

        fetch(currentUrl.toString())
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newProducts = doc.querySelector('.products-grid').innerHTML;
                productGrid.innerHTML = newProducts;
                initializeProductEvents();
            })
            .catch(error => console.error('Error:', error));
    }

    function showQuickView(productId) {
        fetch(`product_detail.php?id=${productId}&quickview=1`)
            .then(response => response.text())
            .then(html => {
                const modal = document.createElement('div');
                modal.className = 'modal fade';
                modal.innerHTML = html;
                document.body.appendChild(modal);

                const modalInstance = new bootstrap.Modal(modal);
                modalInstance.show();

                modal.addEventListener('hidden.bs.modal', function() {
                    modal.remove();
                });
            })
            .catch(error => console.error('Error:', error));
    }

    function initializeProductEvents() {
        // Re-initialize quick view buttons
        const newQuickViewButtons = document.querySelectorAll('.quick-view-btn');
        newQuickViewButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const productId = this.dataset.productId;
                showQuickView(productId);
            });
        });

        // Re-initialize add to cart buttons
        const newAddToCartButtons = document.querySelectorAll('.add-to-cart-btn');
        newAddToCartButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const productId = this.dataset.productId;
                addToCart(productId);
            });
        });
    }

    function addToCart(productId) {
        fetch('add_to_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `product_id=${productId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    updateCartCount(data.cartCount);
                    showNotification('Sản phẩm đã được thêm vào giỏ hàng', 'success');
                } else {
                    showNotification(data.message || 'Có lỗi xảy ra', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('Có lỗi xảy ra', 'error');
            });
    }

    function updateCartCount(count) {
        const cartBadge = document.querySelector('.cart-badge');
        if (cartBadge) {
            cartBadge.textContent = count;
        }
    }

    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }

    // Utility function for debouncing
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
});