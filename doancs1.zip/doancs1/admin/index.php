<?php
session_start();
require_once '../config/database.php';
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}
// Đếm số lượng
$product_count = $conn->query('SELECT COUNT(*) FROM products')->fetchColumn();
$order_count = $conn->query('SELECT COUNT(*) FROM orders')->fetchColumn();
$user_count = $conn->query('SELECT COUNT(*) FROM users')->fetchColumn();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>body{background:#f5f6fa;} .card{border-radius:12px;}</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">Admin Panel</a>
        <div class="d-flex align-items-center ms-auto">
            <span class="text-white me-3"><i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Đăng xuất</a>
        </div>
    </div>
</nav>
<div class="container py-5">
    <h2 class="mb-4">Chào mừng, <?php echo htmlspecialchars($_SESSION['admin_username']); ?>!</h2>
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card text-center p-4 shadow-sm">
                <h4>Sản phẩm</h4>
                <div class="display-4 text-primary"><?php echo $product_count; ?></div>
                <a href="products.php" class="btn btn-outline-primary mt-3">Quản lý sản phẩm</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center p-4 shadow-sm">
                <h4>Đơn hàng</h4>
                <div class="display-4 text-success"><?php echo $order_count; ?></div>
                <a href="orders.php" class="btn btn-outline-success mt-3">Quản lý đơn hàng</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center p-4 shadow-sm">
                <h4>Người dùng</h4>
                <div class="display-4 text-info"><?php echo $user_count; ?></div>
                <a href="users.php" class="btn btn-outline-info mt-3">Quản lý người dùng</a>
            </div>
        </div>
    </div>
</div>
</body>
</html> 