    </div>
    <footer class="mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5>Về TechShop</h5>
                    <p>TechShop - Cửa hàng điện thoại và laptop uy tín hàng đầu Việt Nam. Chúng tôi cam kết mang đến cho khách hàng những sản phẩm chất lượng với giá tốt nhất.</p>
                    <div class="social-links mt-3">
                        <a href="#" target="_blank"><i class="bi bi-facebook"></i></a>
                        <a href="#" target="_blank"><i class="bi bi-instagram"></i></a>
                        <a href="#" target="_blank"><i class="bi bi-twitter"></i></a>
                        <a href="#" target="_blank"><i class="bi bi-youtube"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Liên hệ</h5>
                    <p><i class="bi bi-geo-alt"></i> 123 Đường ABC, Quận XYZ, TP. Hồ Chí Minh</p>
                    <p><i class="bi bi-telephone"></i> Hotline: 0123-456-789</p>
                    <p><i class="bi bi-envelope"></i> Email: contact@techshop.com</p>
                    <p><i class="bi bi-clock"></i> Giờ làm việc: 8:00 - 22:00</p>
                </div>
                <div class="col-md-4 mb-4">
                    <h5>Chính sách</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Chính sách bảo hành</a></li>
                        <li><a href="#">Chính sách đổi trả</a></li>
                        <li><a href="#">Chính sách vận chuyển</a></li>
                        <li><a href="#">Chính sách bảo mật</a></li>
                        <li><a href="#">Điều khoản sử dụng</a></li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; 2024 TechShop. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <img src="assets/images/payment-methods.png" alt="Payment Methods" height="30">
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html> 